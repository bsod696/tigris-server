# node-facedetect-supyo

Please keep in sync with https://github.com/lidio601/node-facedetect-supyo
