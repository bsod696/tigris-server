cp -p /tmp/extract/package/manatee/hardware/N7G1/bin/* /usr/bin
cp -p /tmp/extract/package/manatee/hardware/N7G1/lib/* /usr/lib
