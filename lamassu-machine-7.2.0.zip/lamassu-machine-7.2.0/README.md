# lamassu-machine
The software that runs the Lamassu Bitcoin Machine.

To install, see [INSTALL.md](INSTALL.md).
